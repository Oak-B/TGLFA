def init():
    global a
    a = {}
def set(arg,value):
    a[arg] = value
def get(arg):
    return a[arg]
